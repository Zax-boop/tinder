import React from 'react';
import '../../App.css';
import HeroSection from '../HeroSection.js';

function Home() {
  return (
    <>
      <HeroSection />
      <h1>Hello world!</h1>
      <p>Hello World!</p>
      <p>Hello World!</p>
      <p>Hello World!</p>
      <p>Hello World!</p>
      <p>Hello World!</p>
      <p>Hello World!</p>
      <p>Hello World!</p>
      <p>Hello World!</p>

    </>
  );
}

export default Home;