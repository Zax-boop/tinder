import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import Home from './Components/Pages/Home.js';

ReactDOM.render(<App />, document.getElementById('root'));